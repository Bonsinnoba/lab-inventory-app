# Phase 2 fixed delivery checklist

November 1 V1 2.2.4 owner update: installed and reopened after a full V1 profile
and WebView backup (1,411 files, 2,498,673,127 bytes; all SHA-256 checks pass).
Installed executable reports 2.2.4; live V1 SQLite integrity is OK and the
dashboard displays local data. The viewer's folder browsing, native Save action,
zoom/pan, minimized/expanded states, and the sidebar change were carried in the
same source files used by V2. The shared viewer, folder browser, zoom component,
resources page, sidebar, and music components matched the isolated V1 2.2.4
snapshot byte for byte on this date. V2's App.tsx separately contains the same
lease-expiry polling and login-routing behavior, with other V2 work layered on top.

Open viewer issue for V1 and V2: the media aspect-ratio selector often produces
nearly identical output. ResourceViewerModal.tsx applies `aspectRatio` to an
image/video that also uses `objectFit: 'contain'`; the original media remains
fully contained, so changing the element box mainly changes letterboxing. Define
the control's intended modes (for example Original, Fit, Fill/crop, and explicit
ratio framing), constrain a distinct preview frame in each pane, and apply the
chosen fit/crop behavior to that frame. Keep the underlying file unchanged and
check portrait/landscape images and video in both normal and split views. This is
recorded for the next viewer pass; no aspect-ratio behavior change is claimed in
2.2.4.

October30 primary B1/B2/B4 condition guard: new checkout/consumption and direct
reservation fulfillment now reject damaged/repair/replacement/retired stock.
Native checks use stored status, not a forged next snapshot. Already-issued
custody can still record damage/loss/consumption without another stock debit.
28 native checks PASS, two opt-in live checks ignored; actual PostgreSQL HTTP
and independent condition-change race PASS, including packaged API verification.
Development API and native Preview builds PASS; unchanged frontend assets reused.
No parent closure or V1 update; GUI and separate repair lifecycle remain open.
[Evidence](../handoffs/phase2-parallel/PRIMARY_STOCK_CONDITION_GUARDS_2026-10-30.md).

October29 primary desktop acceptance: separate Preview restored its cached session,
and cold-started with development API confirmed stopped; cached dashboard/project/
stock summaries were present in its accessibility state. SQLite baseline had no
pending changes and a downloaded empty salvage snapshot; backup retained. Recovery
form/reconnect mutation acceptance remains NOT RUN because both native inspectors
returned mismatched screenshots/invalid input geometry. No authored records or
stock changes were made; V1 untouched. API restoration tracked in evidence.
[Acceptance evidence](../handoffs/phase2-parallel/PRIMARY_SALVAGE_DESKTOP_ACCEPTANCE_2026-10-29.md).

October29 primary B1/B2 inspected custody returns: quarantined return intentions
now link the issued holder/quantity and reuse canonical return accounting at
release. Stock, custody settlement, audit and outer receipt commit or roll back
together. Real PostgreSQL HTTP/ordinary-return race, disk SQLite and 13 adapter
checks PASS. Damaged stock cannot enter usable inventory through this path.
Combined Preview/API builds and development deployment PASS; packaged probes PASS
and API/database/storage health OK. GUI acceptance and separate repair handling
remain; V1 untouched. No parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_SALVAGE_CUSTODY_RETURNS_2026-10-29.md).

October29 primary B2 disassembly batches: one native outbox intention now saves
2–25 outputs atomically with one shared source claim. Outputs retain independent
inspection/valuation/release; scrap never credits usable stock. Eleven adapter
checks, TypeScript, real SQLite and actual PostgreSQL HTTP/concurrency matrices
PASS. Combined Preview/API builds PASS; packaged PostgreSQL probes PASS and
development API health is OK. New additive migration applied only to development.
GUI/reconnect acceptance and custody-linked returns remain; no parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_SALVAGE_OUTPUT_BATCHES_2026-10-29.md).

October29 primary B2 follow-on: real PostgreSQL independent concurrent releases
PASS same-recovery idempotency, shared-source ceiling, shared-item ledger balances,
stale-version denial, disabled-actor denial and failure rollback. Consumption-source
selection now uses guarded cached history on desktop and project-filtered browser
reads. Nine adapter checks, disk-backed native test, TypeScript/Vite and combined
Preview native build PASS. GUI acceptance remains separate; Docker is currently
unavailable, so new API deployment is not claimed.
Shared-source multi-output batches and custody-linked returns still need code.
[Evidence](../handoffs/phase2-parallel/PRIMARY_SALVAGE_CONCURRENCY_AND_SOURCE_PICKER_2026-10-29.md).

October29 V1 music hotfix: shared transport replaces render-dependent focus
ownership and delayed play/source races in both full players. Mini controls use
the same guarded transport.23 transport/coordinator checks and real React/browser
audio pause/resume/navigation/mini/focus checks PASS. Shared V2 source retains
the exact same implementation; broader C3/Phase3 audio integration is still open.
V1 2.2.3 installed and relaunched; SQLite and524 music/settings storage files
hash-verified unchanged across installation. Actual owner-file WebView2 playback
smoke check remains; desktop inspector recovery timed out. Evidence is separate.
[Music evidence](../handoffs/phase2-parallel/PRIMARY_V1_MUSIC_TRANSPORT_2026-10-29.md).

October29 owner-requested V1 resource/viewer hotfix delivered separately as2.2.2:
batch/folder selection, Windows frontend drops, folder browsing, movable minimized
viewer,99% expansion, file-header toggle, media display ratios and reachable
image/PDF zoom/pan. Installed and reopened; existing database verified unchanged
by installer, V1 API/database/storage healthy.20 focused checks and isolated viewer
interactions PASS. No Phase2 parent closure or V2 backend shipment to V1.
[V1 evidence](../handoffs/phase2-parallel/PRIMARY_V1_RESOURCE_VIEWER_UPDATE_2026-10-29.md).

October29 primary salvage offline workflow: native account-scoped snapshots and
create/inspect/release intentions now use SQLite -> immutable outbox -> generic
server transactional receipts -> authorized pull. Inventory recovery section and
centered dialogs distinguish pending requests from confirmed stock. Seven adapter
checks, disk-backed SQLite and actual PostgreSQL/authenticated HTTP matrices PASS;
final native/build/deployment/GUI acceptance tracked in the evidence. No V1 changes
and no parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_SALVAGE_OFFLINE_WORKFLOW_2026-10-29.md).

October29 primary salvage authority: shared project visibility now filters
salvage reads. Inspection/release recheck current active user, domain permission
and project edit scope in their transaction. Real PostgreSQL/authenticated HTTP
grant/view/edit/revocation/disabled-account cases PASS, including filtered read
and released-record retry denial; fixtures absent. Source only; native cache/
outbox integration and deployment remain. No parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_SALVAGE_ACCESS_2026-10-29.md).

October29 primary salvage source contract: additive consumption-movement link,
serialized released-source quantity ceiling, source/project matching, explicit
legacy attestation and outstanding-custody return guard implemented. Real
PostgreSQL service and authenticated HTTP matrix PASS; fixtures/migration rolled
back. Source only; native intents, full visibility and multi-output/race tests
remain. No parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_SALVAGE_SOURCE_CLAIMS_2026-10-29.md).

October29 primary salvage correctness: server release now uses valid item types,
real stock movement balances, repeated-release protection and separate reviewed
valuation; inspection cannot overwrite released state. Real development
PostgreSQL rollback probe PASS, fixtures absent. Source only; native salvage
outbox/provenance/over-recovery and integrated concurrency acceptance remain.
This is partial B2 work, not phase closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_SALVAGE_RELEASE_CORRECTNESS_2026-10-29.md).

October29 coordinated deployment: development API image rebuilt/deployed,
health API/database/storage OK; runtime reconciliation source hashes match.
Packaged rollback-only HTTP/PostgreSQL probes PASS from the new container with
all fixtures absent. Preview combined frontend/native build PASS; launch and
desktop acceptance pending failed computer-use recovery. V1 healthy/unchanged.
Dependency audit triage remains; no parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_COORDINATED_PREVIEW_BUILD_2026-10-29.md).

October29 primary project edit permissions: unchanged full-record fields no
longer become unintended server updates; ordinary edits do not require finance
authority merely for carrying an unchanged budget. Native actual budget changes
require finance.edit. Conflicting authored fields enter explicit preserved-work
review. Real PostgreSQL HTTP/replay/denial/conflict cases PASS; 17 native tests
PASS with API stopped; eight conflict UI tests and TypeScript PASS. Legacy
without-before behavior and full desktop deployment remain separate boundaries.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_EDIT_PERMISSIONS_2026-10-29.md).

October29 primary project save/date checkpoint: timestamp-backed calendar fields
now initialize correctly. Production native update/outbox failure rollback and
disk reopen PASS; 17 native project tests PASS with development API stopped.
50 frontend checks and TypeScript PASS. Real PostgreSQL authenticated review
route confirms overlap/consumable allocation rules and unchanged physical stock;
all rollback fixtures absent. Coordinated Preview deployment, GUI restart and
concurrent/reconnect acceptance remain open. No parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_SAVE_DATES_AND_QUEUE_PARITY_2026-10-29.md).

October29 primary local review queue: desktop central reservation review now
derives from existing authorized SQLite project/inventory readers without HTTP
fallback. Missing data stays unknown; local scope and queued decisions are
explicit. Boundary/projection checks 47 PASS; final projection checks 7 PASS.
Header project Save repair rebuilt successfully. Integrated queue deployment,
desktop save/restart and real server reconciliation remain open; GUI input
reported invalid 12x12 window bounds after recovery. No parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_LOCAL_RESERVATION_REVIEW_2026-10-29.md).

October29 task write checkpoint: real authenticated sync-push HTTP + development
PostgreSQL PASS create/update/delete replay, payload/device mismatch rejection,
single tombstone, receipt-insert fault rollback and unchanged-event retry. Four
unique successful receipts; all fixtures absent after rollback. Savepoints isolate
route transactions, so concurrent/independent commit and actual desktop reconnect
remain unverified. V1 stayed running and unchanged; no parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_TASK_WRITE_HTTP_2026-10-29.md).

October29 consolidated project checkpoint: production JWT middleware + actual
project-pull router PASS nine HTTP cases on real development PostgreSQL in an
isolated rollback harness; all fixtures confirmed absent. Backend project/
visibility suite 40 PASS / 1 SKIP, native project suite 16 PASS with API/DB stopped,
TypeScript and whitespace checks PASS. Actual desktop, deployed configuration,
write receipts and reconnect remain open; no parent closure or deployment.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_CONSOLIDATED_ACCEPTANCE_2026-10-29.md).

October28 project visibility checkpoint: eight production SQL policy cases PASS
on development PostgreSQL, including restricted grants and membership/grant
revocation; rollback absence verified. Ten focused visibility/source-contract
tests PASS. This is not JWT/HTTP or native cache acceptance; those remain open.
No production permission change, deployment or parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_VISIBILITY_POSTGRES_2026-10-28.md).

October28 nonempty PostgreSQL collection checkpoint: all six project collections
now pass snapshot shape/identity/uniqueness and per-project/empty-scope checks.
Rollback-only fixtures closed the four earlier nonempty-data gaps; all twelve
temporary rows were confirmed absent through ten cleanup queries. No permanent
seed, V1 change or parent closure. Authenticated endpoints, mutation receipts and
desktop reconnect remain separate acceptance gates.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_COLLECTION_SERVER_SHAPE_2026-10-28.md).

October28 live collection checkpoint supersedes Docker-blocked status below:
actual development PostgreSQL query-shape/empty-scope checks PASS for six
collections; nonempty checks cover 3 blocks and 18 requirements. Four empty
collections still need nonempty fixtures. Native task nested experiment links
now derive from canonical links; all 16 project tests pass. Existing development
DB was temporarily started then restored to stopped; V1 unchanged. Full desktop
acceptance remains open. [Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_COLLECTION_SERVER_SHAPE_2026-10-28.md).

October28 server collection-shape follow-up: source inspection confirms native
project-item composite identity matches API projection. Read-only PostgreSQL
shape/identity probe prepared for six collections. Live execution is blocked by
the unavailable Docker Linux engine; no real-database PASS claimed.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_COLLECTION_SERVER_SHAPE_2026-10-28.md).

October28 project collection matrix: BOM, canvas blocks/connectors, requirements
and composite project-item links now have production-pull regression coverage for
pending create/edit/delete, authoritative absence, repeated pull, disk reopen and
test-only acknowledgment convergence. All 15 native project tests pass; 26 pending
fixture events survive reopen before simulated ACKs. Real server receipts and
desktop acceptance remain open. No new production change or parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_COLLECTION_MATRIX_2026-10-28.md).

October28 experiment child reconciliation: measurements/observation records now
merge independently after pending parent fields, retaining pending child values
and removals while refreshing confirmed rows. All 15 native project tests pass,
including repeated production pulls/reopen with eleven pending events preserved.
Desktop/outage/reconnect acceptance remains open; no deployment or parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_EXPERIMENT_CHILD_PULL_2026-10-28.md).

October28 pending child deletion guard: shared project pull retention now respects
local absence while a child event is pending. Task/experiment deletion regression
passes through repeated production pulls and disk reopen; seven pending events
remain intact. All 15 native project tests pass. Other child collections and
desktop/API convergence remain acceptance gates, not parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_PENDING_DELETIONS_2026-10-28.md).

October28 task–experiment link convergence: fixed loss of pending links when the
server returns the same identity before acknowledgment. Shared relation merge
preserves local pending rows/removals and honors link tombstones. All 15 native
project tests pass, including actual repeated pulls and disk reopen with five
pending events preserved. Desktop/reconnect acceptance remains open; no parent
closure or deployment. [Evidence](../handoffs/phase2-parallel/PRIMARY_TASK_EXPERIMENT_PULL_2026-10-28.md).

October28 attachment pull convergence: server nested attachments now populate the
canonical local collection; pending additions/removals survive pulls and nested
views derive from the same collection. All 15 native project tests pass, including
production pull/reopen coverage; desktop acceptance remains open. No parent closure or
deployment. [Evidence](../handoffs/phase2-parallel/PRIMARY_ATTACHMENT_PULL_CONVERGENCE_2026-10-28.md).

October28 history acceptance refinement: disk regression now runs the actual
project-pull implementation twice, checks foreign-account rejection, preserved
pending fields/event and restart persistence. All 14 native project tests pass.
The Tauri wrapper delegates to the same tested body; no protocol change. Running
desktop UI/IPC/outage/reconnect remains unverified, no parent closure.
[Evidence](../handoffs/phase2-parallel/PRIMARY_EXPERIMENT_HISTORY_PERSISTENCE_2026-10-28.md).

October28 experiment-history native follow-up: matching pending experiment rows
retain authored fields while refreshing the confirmed history array. Fourteen
native project tests passed, including production save/load through a temporary
on-disk SQLite database, close/reopen and immutable pending-outbox assertions.
No personal database touched. Full native pull/desktop reconnect and coordinated
deployment remain open. [Evidence](../handoffs/phase2-parallel/PRIMARY_EXPERIMENT_HISTORY_PERSISTENCE_2026-10-28.md).

October28 experiment history database checkpoint: actual development PostgreSQL
probe PASS for two project scopes, history/endpoint parity, ordering and filtering.
Six rollback-only audit fixtures were verified absent afterward. No V1 changes.
Authenticated route, native persistence and desktop outage/reconnect acceptance
remain open; no parent promoted. [Evidence](../handoffs/phase2-parallel/PRIMARY_EXPERIMENT_AUDIT_HISTORY_2026-10-28.md).

October28 A3/B3/B4 experiment audit-history source integration: authorized project
pull now carries a separate history collection; desktop reads it locally and shows
downloaded audit events separately from saved revisions. Missing legacy history
is unavailable, not empty. 38 adapter + 3 query-contract + 13 editor/refresh checks
passed. Actual PostgreSQL, persistence, desktop outage/reconnect and deployment
remain pending; no parent promotion. [Evidence](../handoffs/phase2-parallel/PRIMARY_EXPERIMENT_AUDIT_HISTORY_2026-10-28.md).

October28 A1/B3 native attachment validation: shared write path now validates
one task/experiment target in the project and canonical resource UUID/current
local presence with resources.view permission. Existing links are preserved.
Source implementation only; native-command/integrated acceptance pending.
Separate experiment audit-history offline support remains open (not equivalent
to saved revisions). [Evidence](../handoffs/phase2-parallel/PRIMARY_ATTACHMENT_WRITE_VALIDATION_2026-10-28.md).

October28 A3/B3/B5 project finance: unknown local inventory/workspace/cost data no
longer becomes zero valuation. Known ledger totals remain available; unknown
valuation is explicit in rows and combined total. Composite reads are session
guarded. 34 focused adapter checks passed; source only, desktop acceptance and
durable completeness still pending. [Evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_FINANCE_AVAILABILITY_2026-10-28.md).

October27 A1/B3 shared project-adapter boundary: require an active captured account
before native IPC and suppress results from a changed account/session. Reject
missing non-delete results without HTTP fallback; persisted work is not discarded.
44 focused frontend checks passed; real desktop account-switch acceptance remains.
Source only, no parent promotion. [Primary evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_ADAPTER_SESSION_2026-10-27.md).

October27 B3/B4 attachment follow-up: native nested attachment reads now join
current resource labels with a resources.view gate and work-item validation.
Unlink/detach/measurement-delete/observation-delete failures now show explicit
feedback. Source implemented; desktop acceptance pending, no parent promoted.
See [primary evidence](../handoffs/phase2-parallel/PRIMARY_PROJECT_ATTACHMENT_FEEDBACK_2026-10-27.md).

October27 B3/B4 nested-project checkpoint: local task/experiment relationships now
join current labels; nested mutation callbacks refresh connected project views.
Task and experiment editors await successful persistence and retain failed drafts.
Three native projection tests and eight frontend handler/refresh checks passed.
Source implemented, not deployed or accepted in the desktop. No parent status or
implementation-ready count is promoted by these bounded fixes. Evidence and open
checks: [primary report](../handoffs/phase2-parallel/PRIMARY_PROJECT_NESTED_EDITING_2026-10-27.md).

## Current execution — October 26: return from personal V1 packaging

The owner requested return to this original A1–C6 checklist. Personal V1 packaging
is a separate handoff, not Phase 2 completion. See
[V1_CLEAN_PERSONAL_SETUP.md](V1_CLEAN_PERSONAL_SETUP.md) for its installed artifact,
isolated data and unperformed acceptance checks. Do not update, stop, seed or test
against the daily-use `labos-v1`/port4010 environment as part of ordinary V2 work.
Development uses the existing `labos`/port4000 environment; preserve both datasets.

V1 interruption is now a separate follow-up: the optional-date/server approval
hotfix was deployed, and the owner reports the desktop updated. Original pending
event replay has not been independently verified. See
[report](../handoffs/phase2-parallel/PRIMARY_PROJECT_BLANK_DATE_2026-10-26.md).
The later external-PowerPoint-viewing installer built successfully and was launched;
installation/opening acceptance remains unconfirmed. Neither V1 follow-up closes
an A1–C6 parent or authorizes ordinary V2 changes to the V1 environment.

Current resumed work: B3/B4 connected-project review/lifecycle and
remaining integration boundaries, then the independent remaining A/B/C code in
the bounded register. Reconcile helper-delivered code before implementing it
again. Retain all 18 parent closure units; no new parent is closed by packaging.
Historical dated checkpoints below retain their evidence-time status, not current
blanket deployment claims. Use dated deployment reports for superseding evidence.

October 26 resumed B3/B4 check: added native pending-child review regression matrix
for tasks, experiments, BOM, canvas, requirements, attachments, task/experiment
links, item links and measurement/observation events; verifies both project-ID
payload shapes, account/project isolation and refreshed displayed-token handling.
All 10 native review tests passed with the development API confirmed stopped,
including 66 nested-event combinations. Production code unchanged. Results and remaining
gates: `docs/handoffs/phase2-parallel/PRIMARY_REVIEW_NESTED_WORK_2026-10-26.md`.

Deferred Phase3 packaging polish: owner reports generic/missing V1 shortcut icon;
explicitly leave it unchanged for now. This is not a sync or database defect.

October27 owner-approved Phase3 navigation consolidation: use one right-dock
Tools & settings entry that opens in the main workspace, not a narrow dock panel.
Workspace tabs: Media, Daily use, System. Retain search shortcuts, existing
permissions and device/account/lab setting boundaries. Downloads remains a separate
page. Advanced settings may use centered modals; the assistant can remain open.
Inspect and reuse existing controls; this decision does not authorize a backend
rewrite. Missing underlying functionality/offline behavior remains Phase2 work.

## Historical October 24 approved V1 pilot priority

Owner approved a controlled own-lab pilot targeting October 25, rather than full
Phase 2 completion. [V1_LAB_PILOT_RELEASE.md](V1_LAB_PILOT_RELEASE.md) governs pilot
gates and conditional deferrals. A1–C6 below remain the complete backlog; no parent
is closed by the scope change. Preserve all current data. Backup/isolated restore,
core correctness, permissions and offline/reconnect remain release gates.

Owner-approved execution reset, October 13, 2026. This is the single remaining
delivery/status checklist. It consolidates existing commitments; it does not add
a fourth phase, erase evidence, authorize data loss, or move functionality into
Phase 3. Detailed requirements remain in the linked source plans below.

## Baseline and rules

October27 A3/B3/B4 local context: desktop project context now composes existing
authorized local readers with section availability and account lifetime guards,
without HTTP fallback; reservation/review/checkout saves refresh connected views.
35 focused regressions passed. Source only, integrated desktop acceptance pending,
V1 unchanged. Report: `docs/handoffs/phase2-parallel/PRIMARY_LOCAL_PROJECT_CONTEXT_2026-10-27.md`.

October27 B3/B4 plan-view consistency: shared post-save query refresh for BOM,
workspace child and canvas mutations; corrected BOM form rejection of two absent
optional inventory choices. Three focused tests pass; interactive acceptance
pending, V1 untouched. Report: `docs/handoffs/phase2-parallel/PRIMARY_PROJECT_PLAN_REFRESH_2026-10-27.md`.

October27 A3/B3/B4 project activity: connected the existing authorized local audit
snapshot to the desktop workspace, filtering before the 100-row display limit.
Explicit missing/restricted/unavailable/freshness states replace false empty
history. Three native tests passed; integrated desktop acceptance pending; V1
unchanged. Evidence: `docs/handoffs/phase2-parallel/PRIMARY_PROJECT_ACTIVITY_2026-10-27.md`.

October27 B3/B4 Knowledge integration: replaced desktop resource and note empty
placeholders with permission-checked account-local reads, corrected attachment
labels/native link arguments and refreshed affected query families. Source only;
no V1 update. Desktop acceptance remains open. Reports:
`docs/handoffs/phase2-parallel/PRIMARY_RESOURCE_ATTACHMENT_DISPLAY_2026-10-27.md`
and `docs/handoffs/phase2-parallel/PRIMARY_PROJECT_KNOWLEDGE_2026-10-27.md`.

October27 permission HTTP follow-up: eight real authenticated loopback HTTP scenario
groups passed against rollback-only development PostgreSQL fixtures, including
mid-request actor revocation, audit rollback and malformed-body protection. Explicit
[] still clears overrides. Source only; deterministic race injection/savepoint
transaction limits recorded; no V1 changes. Report:
`docs/handoffs/phase2-parallel/PRIMARY_PERMISSION_HTTP_2026-10-27.md`.

October27 A1/B3/B4: permission replacement now rechecks current actor authority under
ordered actor+target account locks and authorizes implicit override removals. 16
focused tests and rollback-only real PostgreSQL lock/authority checks PASS. Source
only, no V1 update; full HTTP/concurrent request acceptance remains. Report:
`docs/handoffs/phase2-parallel/PRIMARY_PERMISSION_WRITER_AUTHORITY_2026-10-27.md`.

October 27 resumed B3/B4: real development PostgreSQL two-connection tests passed
for task/experiment/canvas updates and rollback-only BOM insertion. Both parent/
child lock orders, revision advancement and stale-token rejection verified. No
committed changes; development DB restored stopped, API stayed stopped, V1 untouched.
This is not full HTTP/desktop reconnect acceptance. Report:
`docs/handoffs/phase2-parallel/PRIMARY_REVIEW_CHILD_CONCURRENCY_2026-10-27.md`.

October 24 native review follow-up: displayed token is required at the native
save boundary. Durable file-backed queue/reopen/duplicate-ACK/delayed-snapshot
test PASS; 44 focused tests passed with API stopped. Source only. Live desktop
reconnect acceptance still open. Report:
`docs/handoffs/phase2-parallel/PRIMARY_REVIEW_NATIVE_PERSISTENCE_2026-10-24.md`.

October 24 browser/version follow-up: browser approvals now require the displayed
plan token; permission replacement locks the account before overrides. Nine real
PostgreSQL scenarios, two-connection lock checks, 57 API-stopped regressions and
TypeScript PASS. Source only; remaining native/reconnect/concurrency acceptance
is explicit in `docs/handoffs/phase2-parallel/PRIMARY_REVIEW_BROWSER_VERSION_2026-10-24.md`.

October 24 authority follow-up: HTTP and sync share transactional current review
authority in source. Eight PostgreSQL handler scenario groups, two-connection
project/account row-lock checks and 30 API-stopped regressions PASS. Not deployed;
predicate/permission-writer races and full workflow acceptance remain. Report:
`docs/handoffs/phase2-parallel/PRIMARY_REVIEW_AUTHORITY_2026-10-24.md`.

October 24 follow-up B3/B4: plan revision guard implemented in source; seven
actual PostgreSQL push-handler/migration scenario groups PASS, plus 12 focused
tests with the API stopped. Not deployed. Concurrency, durable reconnect and
HTTP authority/integrated desktop gates remain. Report:
`docs/handoffs/phase2-parallel/PRIMARY_REVIEW_PLAN_VERSION_2026-10-24.md`.

October 24 B3/B4: review native outbox/server path connected in source; focused
offline and PostgreSQL handler checks pass. Do not close or deploy: whole-plan
version guard and actual sync replay/integration gates remain. Report:
`docs/handoffs/phase2-parallel/PRIMARY_REVIEW_QUEUE_2026-10-24.md`.

October 23 B3/B4 review atomicity foundation: decision/event/audit now share the
HTTP transaction in source, verified against PostgreSQL with rolled-back fixtures.
Native review queue and idempotent replay remain open; not deployed. Report:
`docs/handoffs/phase2-parallel/PRIMARY_REVIEW_ATOMICITY_2026-10-23.md`.

October 23 B3/B4 project review: cached confirmed review reads implemented in
source and focused checks passed. Queued decisions/atomic audit are still open,
not claimed completed by this read change. Deployment/integration pending. See
`docs/handoffs/phase2-parallel/PRIMARY_PROJECT_REVIEW_READ_2026-10-23.md`.

October 23 B3/B4 revision-history update: authorized experiment revisions added
to project sync snapshots; desktop reader uses native snapshot without HTTP
fallback. Source-only, integration/deployment still pending. See
`docs/handoffs/phase2-parallel/PRIMARY_EXPERIMENT_REVISIONS_2026-10-23.md`.

October 23 B3/B4 update: observation prose/record collision fixed in source,
focused offline and read-only PostgreSQL checks pass. Coordinated deployment,
desktop acceptance and ambiguous legacy-event recovery remain open. See
`docs/handoffs/phase2-parallel/PRIMARY_EXPERIMENT_OBSERVATIONS_2026-10-23.md`.

October 23 primary B3/B4: measurement/observation collection reads no longer
fall through to HTTP on desktop local misses or accept missing/non-array fields
as valid collections. TypeScript and 15 boundary tests PASS with API stopped,
restored healthy. Source-only. Project history/review projections, observations
prose/collection field collision and UI availability remain open. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_EXPERIMENT_READ_BOUNDARIES_2026-10-23.md`.

October 23 coordinated sync-safety deployment: runtime account isolation,
fail-closed preflight and dedicated native queue-status reader now deployed
together after saved-edit approval. TypeScript/Vite/native builds PASS; 28 frontend
+ 12 native checks PASS with actual API stopped; restored healthy. Original
database/storage preserved. Earlier source-only notes are historical. Integrated
desktop acceptance remains open; no parent closure. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_SYNC_SAFETY_DEPLOYMENT_2026-10-23.md`.

October 23 primary A1: dedicated native account/lease-bound queue-count command
implemented; renderer preflight/panel now use it without diagnostic-command or
HTTP fallback. TypeScript/native test build PASS; 28 frontend + 12 native checks
PASS with API stopped, restored healthy. Source-only; deploy with runtime
isolation/preflight fixes. No parent closure. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_NATIVE_QUEUE_STATUS_2026-10-23.md`.

October 23 primary A1/A2: unreadable/malformed local queue preflight now stops
sync instead of treating ownership counts as zero. Explicit retry repeats the
check; automatic retry respects account-scoped backoff. TypeScript and 28 focused
tests PASS with API stopped; restored healthy. Source-only, awaiting deployment
with runtime isolation and integrated acceptance. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_SYNC_PREFLIGHT_2026-10-23.md`.

October 23 primary A1: account-scoped sync runtime status/backoff and login-bound
late-update guards implemented in source. Generation checks now cover sync
preflight and prevent a new login joining the old run. TypeScript and 25 focused
tests PASS with actual API stopped; restored healthy. Awaiting coordinated build
and integrated account-switch acceptance; no parent closure. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_SYNC_RUNTIME_ISOLATION_2026-10-23.md`.

October 23 primary deployment: recovery index and full/compact conflict view
lifetime guards deployed in rebuilt desktop after saved-edit approval. Queue
status read errors now remain unknown, not zero/no conflicts. TypeScript, Vite
and native build PASS; 18 focused checks PASS with API confirmed stopped; existing
PostgreSQL/API restarted healthy with original volumes. Integrated desktop
acceptance and recovery-content export remain open. No parent closure. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_SYNC_PANEL_READS_2026-10-23.md`.

October 22 primary A1/B4: conflict/recovery renderer request lifetime guarded;
superseded reads cannot overwrite newer state, authentication events clear the
view and resolution continuations reject account switches. 15 focused checks
PASS with API stopped, restored healthy. Source-only; integrated desktop
acceptance remains open. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_CONFLICT_VIEW_LIFETIME_2026-10-22.md`.

October 22 primary A2/B4: read-only owned project-deletion recovery index added in
source, metadata only with no historical project content/authority exposed.
TypeScript/native build PASS; 12 adapter/render + 10 native checks PASS with API
stopped; restored healthy. Awaiting coordinated native/UI deployment and desktop
acceptance. Payload inspection/export remains open. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_PROJECT_RECOVERY_INDEX_2026-10-22.md`.

October 22 coordinated deployment: history guard, native recovery, conflict UI and
account fence now deployed together after saved-edit approval. Frontend/native
builds PASS; deployed PostgreSQL 23 focused + 29 handler PASS (rollback verified),
11 adapter/render PASS. Existing data/volumes retained; updated desktop launched.
Earlier source-only notes below are historical. Integrated desktop/recovery export
and parent acceptance remain open. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_CONFLICT_DEPLOYMENT_2026-10-22.md`.

October 22 primary A1/B4: conflict account/session fence implemented in source;
11 adapter/render and 9 native checks PASS with API stopped, API restored healthy.
UI/native must deploy together; two-login desktop acceptance still open. Existing
desktop launched, latest source not deployed. No parent closure. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_CONFLICT_ACCOUNT_FENCE_2026-10-22.md`.

October 22 primary B4 conflict UI: both sync views share explicit Cancel deletion /
Use server status guidance, disable protected/stale retries and retain native
authority. Seven presentation/render checks PASS with API stopped; TypeScript
PASS and API restored healthy. Awaiting deployment/desktop interaction acceptance;
no recovery export or parent closure. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_PROJECT_CONFLICT_GUIDANCE_2026-10-22.md`.

October 22 primary B4/A2 recovery subcheck: native conflict resolution now blocks
blind history-protected deletion/lifecycle retries and atomically preserves an
account-scoped deletion recovery record before explicit retirement. 8 native
local_db tests PASS with actual API stopped, including disk reopen and failure
rollback; API restored. Awaiting deployment/integrated verification; recovery UI
and broader project reconciliation remain open. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_PROJECT_DELETE_RECOVERY_2026-10-22.md`.

October 22 primary B4: shared project deletion guard now protects financial,
purchase, salvage and scientific evidence/provenance in source. Real PostgreSQL:
23 focused and 29 handler checks PASS, rollback verified. Awaiting deployment and
integrated acceptance; no parent closure. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_PROJECT_RECORDED_HISTORY_2026-10-22.md`.

October 21 deployment correction: the lifecycle API migration and coordinated
desktop/UI build described below were deployed successfully after owner approval.
API/database/storage health passed; existing volumes and app data preserved.
Deployed-code probes: 12 focused and 27 handler checks PASS, rollback verified.
Integrated desktop/concurrent-client acceptance remains open. See deployment
checkpoint in `PRIMARY_PROJECT_LIFECYCLE_2026-10-21.md`; earlier pending-deployment
statements below are historical, not the current deployment state.

October 21 primary B4 lifecycle batch: core revision-fenced cancellation/archive,
unused reservation release, inventory settlement projection and native pending
state implemented in source. PostgreSQL 12 focused / 27 handler checks PASS;
stopped-API native project/inventory 43 PASS. Awaiting coordinated deployment and
integrated acceptance; broader B4 revision/review/recovery/history work remains.
Evidence: `docs/handoffs/phase2-parallel/PRIMARY_PROJECT_LIFECYCLE_2026-10-21.md`.

October 21 primary B4 safeguard: project deletion now rejects inventory history
in sync and browser routes in source. PostgreSQL: 6 focused checks and 25 handler
regressions PASS, rollback verified. Awaiting deployment/end-to-end verification;
cancellation, archive and settlement remain open. Parent B4 unchanged. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_PROJECT_HISTORY_GUARD_2026-10-21.md`.

October 21 primary follow-up: native/HTTP reservation request-review and rejected
approval retry subcase is **VERIFIED CLOSED in tested source**. A discovered
conflict-domain omission was fixed with access/role guards. Full live test passed;
38 native inventory checks passed with API stopped. Fix awaits next desktop build.
No parent state changed; GUI and multi-client acceptance remain open. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_RESERVATION_REVIEW_ACCEPTANCE_2026-10-21.md`.

October 21 primary bounded acceptance: reserved consumption through native disk
SQLite, actual API outage, deployed HTTP/PostgreSQL sync, lost-ACK replay and
repeated pull convergence is **VERIFIED CLOSED** (one opt-in integration test,
pass; guarded fixture cleanup verified). This does not close B1/B3/B4, GUI
interaction, login, request/review conflict lifecycle or multi-client contention.
Evidence: `docs/handoffs/phase2-parallel/PRIMARY_RESERVATION_HTTP_ACCEPTANCE_2026-10-21.md`.

Exactly 18 remaining delivery items, in three implementation batches. These are
closure units of unequal size, not a percentage or an estimate of days. Existing
working code stays in place. A build, restart or additional unit test is evidence,
not a delivery item completed.

Baseline from the dated evidence ledger: 12 items have PARTIAL implementation;
6 are PLANNED. None of these remaining items is certified closed. This does NOT
mean earlier Phase 2 work is zero percent complete. Delivered foundations include
inventory versions/imports, maintenance, catalogs, hybrid preferences, comments,
notifications, local reports/activity/download paths, native authentication,
resource uploads/replication and Markdown/PDF/DOCX editor paths. Reuse them.

States: PLANNED -> PARTIAL -> IMPLEMENTED -> CLOSED. IMPLEMENTED means every
listed behavior exists and critical checks pass; CLOSED additionally requires
fresh applicable phase-end acceptance evidence. Record a blocker alongside the
state, with its exact prerequisite. Initial statuses are reconciled from existing
evidence, not a new claim of exhaustive source or live-app verification.

Within each fixed item, track bounded subchecks as **CODE REMAINING**,
**DEPENDENCY (named below)**, **IMPLEMENTED — AWAITING VERIFICATION**, or
**VERIFIED CLOSED**. Approval removes a decision blocker; it never substitutes
for implementation. A parent remains PARTIAL until all its required code exists.

- Freeze the IDs and scope below. New defects attach to the responsible item;
  maintain a bounded subcheck/defect list there instead of creating more projects.
  A genuinely new requirement needs explicit owner approval and an impact note.
  Never omit an existing commitment merely because it was missed in this index.
- Implement coherent batches with quick builds and critical auth/stock/sync checks.
  Do not restart/redeploy after each small edit. Coordinate deployment at useful
  batch boundaries; obtain saved-edit confirmation before closing the desktop.
- Run the complete acceptance sweep after implementation. Collect independent
  failures, mark dependent cases BLOCKED, apply grouped fixes, then rerun the full
  matrix. Stop affected work immediately for data-loss/corruption/security risks.
- Preserve databases, authored files, outboxes and unrelated working-tree changes.
  No reset, broad reseed, destructive recovery or automatic ownership reassignment.
- Each update names IDs changed, remaining counts, acceptance status and blockers.
  No completion percentage inferred from item counts. No whole-phase sign-off
  while implementation, required decisions or acceptance remain unresolved.

## Batch A — offline, security and resources

October 18 primary A1/B6 subcheck: H1-4 account-bound inventory history/custody/
assignee response guards and failed-query display masking are implemented in
source (53 contract/component checks PASS), awaiting integrated desktop verification.
Online read-refresh decoupling and the other B6 behaviors remain open. No parent
state changed. Evidence: `docs/handoffs/phase2-parallel/PRIMARY_INVENTORY_READ_GUARDS_2026-10-18.md`.

| ID | State | Required closure behavior / remaining boundary |
| --- | --- | --- |
| A1 | PARTIAL | Finish native account/lease/project/record permission coverage, cached resource edit grants (including notes/folders/restricted records), legacy cache trust and stale-response isolation. Preserve existing native-verified auth/revocation/backoff; add draft-preserving mid-session reauthentication. Review CSP, direct transports and token-bearing media paths. No permission or lease bypass. |
| A2 | PARTIAL | Protect credentials and implement owner-approved recoverable key/storage lifecycle for SQLite, WAL/temp, files, thumbnails and backups. Finish authorized recovery/export of legacy, revoked/deleted-resource and rejected pending work; preserve authorship. Explicit retention/quota/reclamation rules must protect authored/unacknowledged versions and shared references. Recovery choice is a prerequisite, not permission to use a lossy device-only key. |
| A3 | PARTIAL | Finish durable initial-download completeness, last successful sync and pending status for Dashboard, Operations, Lab Intelligence, Reports and Collaboration. Connect local audit/report/context/history projections; preserve partial authorized sections and distinguish unknown from empty. Existing local reports/activity implementations are not to be rewritten. |
| A4 | PARTIAL | Complete file/thumbnail availability across Resources, canvas attachments, item pictures and datasheets; finish local large-file export, media seek/range compatibility and PDF structural/security handling. Replication must resume, verify bytes, report storage failures and remain account-scoped. Metadata alone is not a PC copy. |
| A5 | PARTIAL | Finish resource operation dependencies: DOCX copies of unsynced sources, pending attachment/metadata chains, folder/nested moves, and editor-copy/content retry/recovery. Preserve originals, stable IDs, revisions and immutable events. No local-error -> HTTP fallback; existing upload/Markdown/PDF/DOCX paths remain the foundation. |
| A6 | PARTIAL | Tool-status cache and browser enqueue receipt parity are implemented, awaiting integrated verification. Finish worker/queue/file-readiness reconciliation; ensure cancel/completion races, deletion/tombstones and revocation cleanup preserve correct local/server state. Existing local controls/settings/queues remain. Pending cancel is not server-confirmed cancel; stale pulls cannot resurrect an authorized deletion. |

Batch exit: all six implementation boundaries addressed, evidence and defects
linked by ID, coordinated app/API build available. Acceptance remains separate.

## Batch B — inventory, projects and finance

October 20 reservation intent server checkpoint (primary, B3/B4): request and
confirm/reject/release sync handlers implemented with immutable identity, current
authority, stock allocation guards and atomic audit/receipt. Real PostgreSQL
handler regression batch 20 PASS, rollback verified. Native request/review
intentions, projections and UI wiring remain CODE REMAINING; no offline approval
authority is enabled. No parent/count changes. Next: native intentions and
ACK/pull/rejection reconciliation, then stopped-API/reconnect acceptance.
Evidence: `docs/handoffs/phase2-parallel/PRIMARY_RESERVATION_INTENTS_SERVER_2026-10-20.md`.

October 20 checkout UI follow-up (primary): confirmed allocations now expose
Issue to recipient, with centered recipient/quantity/serial/note dialog and
submission-time permission/session/allocation checks through the existing native
movement adapter. Source implementation; 52 adapter and 30 native checks passed
with API stopped (one integration case ignored). Actual desktop interaction and
reconnect acceptance remain pending; task/experiment selection, reservation
request/review/consumption intents and lifecycle work remain open. No parent
status/count changes. See latest PHASE2_EVIDENCE.md entry.

October 20 later primary B1/B3/A1/A5 checkpoint: native reservation-backed issue
and durable allocation overlays implemented with atomic SQLite/outbox, cached
authority and canonical work checks. Server reservation snapshots carry fulfillment
identities; ACK/pull ordering and explicit rejection recovery preserve allocations
and authored work. Desktop projected reservation reads have no HTTP fallback.
PostgreSQL batch 14 PASS; stopped-API native inventory 30 PASS / 1 IGNORED,
project/local DB regressions 8 PASS; adapter batch 48 PASS. Source only, awaiting
integrated desktop acceptance. Checkout UI, other reservation intents and their
read-after-write integration remain CODE REMAINING. Full implementation-ready
0/18; closed 0/18; all existing parent boundaries remain open. Next: checkout UI
and reservation intent integration, then coordinated deployment/acceptance.
Evidence: `docs/handoffs/phase2-parallel/PRIMARY_RESERVED_CUSTODY_NATIVE_2026-10-20.md`.

October 20 primary B1/B3 subcheck: reservation-backed custody server operation
implemented with transactional allocation/history, authority and quantity guards;
real PostgreSQL handler batch 13 PASS with full rollback. Source request/schema
compatibility and lock-order fixes included; migration NOT deployed. Native offline
reservation projection, pull/rejection reconciliation and checkout UI remain CODE
REMAINING; direct-route/concurrency acceptance remains unverified. No parent status
or implementation-ready/closed count changed.
Evidence: `docs/handoffs/phase2-parallel/PRIMARY_RESERVED_CUSTODY_SERVER_2026-10-20.md`.

October 19 primary B3/B4/A1 subcheck: same-project requirement/work/canvas
relationship guards and stored-owner sync authorization implemented in source.
Foreign link deletion is rejected; valid connector updates no longer reference a
missing timestamp column. Native project batch 4 PASS with API/DB stopped; expanded
real PostgreSQL handler batch 8 PASS, rollback verified. Not deployed/integrated
acceptance. Reservation-backed issue, local reservation intents/projection,
browser parity, demand aggregation and lifecycle settlement remain CODE REMAINING.
Project post-commit audit atomicity remains open. No parent status/count changes.
Evidence: `docs/handoffs/phase2-parallel/PRIMARY_PROJECT_RELATIONSHIP_GUARDS_2026-10-19.md`.

October 19 primary B1 subcheck: dedicated native custody intent/quantity writer
implemented; movement-before-custody FK ordering and settlement numeric SQL repaired
and checked against real PostgreSQL (8 PASS, complete rollback). Renderer offline
batch 55 PASS; native arithmetic 4 PASS. Follow-up native inventory batch: 21 PASS,
0 FAIL, 1 IGNORED, including eight on-disk custody cases with API stopped. Fixed
wrong-item/duplicate custody cache acceptance. Native atomicity and connection-reopen
subcheck verified; not deployed. Integrated server replay, reservation/project
coupling and remaining B1 behaviors are still open. B1's stale PLANNED label is
reconciled to PARTIAL, not acceptance closure. See
`docs/handoffs/phase2-parallel/PRIMARY_CUSTODY_REPAIR_2026-10-19.md`.

Further October 19 primary B1/A2 subcheck: real PostgreSQL push-handler replay and
receipt-failure batch 5 PASS (rollback-only; no HTTP/auth middleware or parallel
acceptance). Explicit rejection resolution now preserves account-owned recovery
snapshots and outbox payloads, invalidates rejected custody and blocks new writes
until authorized server reconciliation. Native inventory 24 PASS/1 IGNORED;
local DB/import regressions 7 PASS; receipt processing 3 PASS, with server stopped.
Recovery UI/export/retention and deployed/multi-client integration remain open.
No parent closure. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_CUSTODY_SYNC_RECOVERY_2026-10-19.md`.

| ID | State | Required closure behavior / remaining boundary |
| --- | --- | --- |
| B1 | PARTIAL | Quantity-aware custody: separate responsible person from physical issue; split issues, recipients/transfers, partial return/consumption/damage/loss and outstanding balances. Consuming issued stock cannot deduct storeroom stock twice. Preserve provenance, units, permissions and provisional offline allocation. Existing assigned_to is not evidence of a physical issue. |
| B2 | PARTIAL | Quarantine/source claims, inspected release, native outbox/source pickers, shared-source output batches and usable custody-linked returns implemented. PostgreSQL HTTP/concurrency, SQLite, coordinated Preview/API builds and development deployment PASS. Complete GUI outage/reconnect acceptance. Separate damaged-return repair handling and browser authoring/retry parity remain boundaries. Preserve original consumption, reviewed valuation and no invented cash refund. See October29 primary evidence. |
| B3 | PARTIAL | Audit and complete canonical links among projects, BOM revisions, requirements, reservations, tasks, experiments, canvas, notes/resources and financial evidence. Shared demand must not be double-counted; visual references must not duplicate/delete underlying records. Finish remaining local mutation/repeat/revision paths and remove missing-record server fallbacks. |
| B4 | PARTIAL | Finish project review/reservation/history/context projections and queued submissions/decisions. Define and implement revision, cancellation, reservation release, archive/delete and closure propagation while preserving custody/results/audit/finance history. Task completion must not silently consume stock or fabricate results; global acceptance remains distinct from local intent. |
| B5 | PARTIAL | Finish finance/purchase local templates, export, preview and transactional workbook imports; remaining purchase/finance mutations use stable retry identity, atomic local/outbox writes and server reconciliation. Enforce financial permissions, concurrency and all-or-nothing effects. Retain existing inventory-import implementation. |
| B6 | PARTIAL | Close remaining inventory/storage relationships, field/assignment history and authorized assignee directory; local inventory templates/export, workbook parser hardening and legacy-event recovery. Preserve existing versioned CRUD/bulk/movements/import/history fixes and explicit snapshot completeness. Apply the common sync contract across remaining uncovered domain operations. |

November 1 primary B2 bounded subcheck — salvage sync audit atomicity: salvage
outbox application now writes its required audit row on the same PostgreSQL
transaction as the mutation and idempotency receipt. Audit failure aborts the
whole operation; idempotent replay does not add another audit row. Code-path
review only; real PostgreSQL fault-injection and normal/replay audit-cardinality
checks remain for the phase-end sweep. Legacy direct browser salvage routes have
separate audit gaps and remain open. B2 remains PARTIAL; no parent or closure
count changed. Evidence:
`docs/handoffs/phase2-parallel/PRIMARY_SALVAGE_SYNC_AUDIT_ATOMICITY_2026-11-01.md`.

Batch exit: functional connected workflows, not isolated forms; explicit stock,
custody and finance effects with no double accounting. Resolve business-rule
choices before dependent migrations; continue independent items meanwhile.

## Batch C — assistant, audio and queued actions

| ID | State | Required closure behavior / remaining boundary |
| --- | --- | --- |
| C1 | PLANNED | Authorized, schema-validated project/task/experiment proposals with stable IDs, versions, context provenance and persistent editable drafts. Saved drafts work offline; generation remains provider/server-dependent. Keep conversation/message/request retry separate from deliberate regeneration. |
| C2 | PLANNED | Human-reviewed proposal acceptance through ordinary native repositories/outbox and idempotent server graph apply. Recheck permissions/scope, attribute to the approver, prevent double acceptance and partial bundles masquerading as complete. No assistant stock movements, spending, grants, destructive deletes or fabricated physical results. Depends on A1 and B3/B4. |
| C3 | PLANNED | One device audio-focus coordinator for music, lab media, TTS and microphone: owner tokens, cancellable transitions, preserved position/volume, manual-pause intent and safe release on errors/navigation/account change. Stale callbacks cannot resume audio under another owner. |
| C4 | PLANNED | Establish and implement the voice capability/privacy boundary needed by Phase 3 controls: supported provider/runtime choice, explicit recording/stop/cancel, transcript review before send, no silent upload/submission and text fallback. Integrate microphone with C3; do not claim offline recognition without evidence. Polished composer controls remain Phase 3. |
| C5 | PARTIAL | Local automation due-item projection and durable run intentions, stable run IDs, uncertain-result reconciliation and server-side permission/idempotency checks. Pending intentions survive restart but are not displayed as executed effects. |
| C6 | PARTIAL | Authorized cached users/permission/settings views and approved ordinary profile/preference intentions; complete remaining online-authoritative retry/cache contracts. Administrative intentions cannot grant effective offline authority; password/reset actions remain server-confirmed and never queue plaintext passwords. Preserve implemented hybrid preferences. |

Batch exit: permissioned functional flows and clear online-only boundaries.
Composer visual polish and release certification remain Phase 3, not correctness.

## Approved decisions — October 14 implementation contract

The owner explicitly selected all five recommendations. These policy blockers
are resolved; the dependent code and acceptance are not thereby complete.

- **A2 — owner-held recovery.** Windows-protected everyday access plus a separately
  stored encrypted recovery package and recovery secret. Do not give every admin
  automatic decryption access. Recovery requires backed-up database/files as well
  as keys. Losing every backup remains unrecoverable. Migration must preserve and
  verify originals, pending outbox events and authored versions before any switch;
  no destructive cleanup or lossy device-only key policy is authorized.
- **B1 — quantity-first custody, optional serials.** Assignment is responsibility,
  not physical issue. Support split issues, recipients/transfers, outstanding
  balances and partial returns. Only explicitly authorized stock handlers post
  movements. Unserialized units cannot be individually traced. Consumption from
  custody must not subtract storeroom stock a second time.
- **B3/B4 — canonical demand and explicit settlement.** Tasks/experiments reference
  the same project requirement; extra demand is explicit, not inferred twice.
  Cancellation releases unused reservations only. Issued stock stays outstanding
  until recorded return, consumption or loss. An unsettled project may be archived
  but must not be labeled fully settled. Preserve results and financial history.
- **B2 — reviewed salvage value.** Preserve original cost/consumption and provenance;
  recovered parts enter quarantine pending human inspection. Record a separately
  reviewed recovery value, with unknown remaining unknown. No automatic project
  expense credit, cash refund or invented purchase transaction.
- **C4 — consented server transcription first.** Use a configured provider with
  disclosed processing/retention. Recording is user-initiated and cancellable;
  the transcript is reviewed/edited before sending, never automatically submitted.
  Connectivity is required; this does not promise offline speech recognition.
  Provider/runtime integration and C3 microphone focus remain implementation work.

No further answer is required for those five choices. New material tradeoffs must
still be surfaced with pros/cons; do not reopen these approvals merely because
implementation has not begun. Retention defaults must protect authored and
unacknowledged work; approval of encryption is not approval to delete originals.

## Bounded implementation register — October 14

This register splits progress inside the same 18 items, not into new phases.
Historical evidence remains linked below. None of these source-only changes is
a deployed-build or integrated-acceptance claim.

| Parent | Bounded subcheck | Status | Remaining implementation / dependency |
| --- | --- | --- | --- |
| A1/A5 | Native-fetched resource/ancestor/destination grants, native-authored file proof and verified file confirmation | IMPLEMENTED — AWAITING VERIFICATION | Broader A1 writer/security audit and A5 mixed/partial-ACK chains remain separate code obligations. |
| A1/A5 | Uninterrupted direct move/metadata chains and strict metadata patches | IMPLEMENTED — AWAITING VERIFICATION | Not content-after-move, mixed creation/content chains, legacy intents or nested moves. |
| A1/A5 | Native-verified mutation receipts and direct move/metadata partial-ACK continuation | IMPLEMENTED — AWAITING VERIFICATION | October 15: exact intent/result digest binding, atomic native receipt/authority/ACK, confirmed-prefix reconstruction without rewriting saved intents. Mixed file-prefix chains and legacy ACKs without native receipts remain separate code obligations. Compile and real outage/authority-race acceptance tracked in evidence. |
| A6 | Account-scoped last checked server-tool status, bounded probes and explicit unknown/stale display | IMPLEMENTED — AWAITING VERIFICATION | Integrated snapshot persistence, stopped-API cold restart and access-revocation cases. |
| A6 | Browser enqueue request identity and transactional server receipt parity | IMPLEMENTED — AWAITING VERIFICATION | Real PostgreSQL concurrent/lost-ACK/revocation cases; browser build and API must deploy together. |
| A6 | Attempt-owned worker lifecycle, cancellation/completion guards and current requester authorization | IMPLEMENTED — AWAITING VERIFICATION | October 15: dedicated job leases, run-ID fences, preserved attempt files and bounded process/thumbnail handling. Actual PostgreSQL/process-race acceptance remains. |
| A6 | Cross-device download-history removal markers | IMPLEMENTED — AWAITING VERIFICATION | October 15: transactional server markers and native monotonic merge prevent old receipts/pulls from reviving removed history; resource/file deletion is separate. |
| A6 | Downloads-page PC-copy status and local preview routing | IMPLEMENTED — AWAITING VERIFICATION | October 15: native-only metadata/copy observations; server completion is separate from current-resource PC availability; no desktop HTTP thumbnail fallback; stale revision/origin copies are not current. Real stopped-API/cold-restart/account-switch verification remains. |
| A6 | October 16 queue-reader defect and automatic saved-link intake | DEPLOYED — AWAITING INTEGRATED VERIFICATION | Native view `rowid` fix deployed. Replacement automatically lists saved media links in Downloads as Awaiting schedule; scheduling there uses existing outbox/identity. 28 focused frontend checks, TypeScript and 9 native tests pass, including actual SQLite read/scheduled-retry rollback with API stopped. Rebuilt app running; Resources buttons confirmed removed. Downloads UI inspection blocked by computer-use helper's invalid window bounds. Worker/reconnect acceptance remains open. |
| A6 | Remaining consumers, legacy removal reconciliation and revocation cleanup | CODE REMAINING | Complete remaining consumers and retained-byte policy; no new owner decision required. Historical deletions without receipts are not guessed. |
| A2 | Recoverable encryption, non-destructive migration/restore and retention | CODE REMAINING | Owner-held recovery is approved. Implement key/data backup verification and recovery; approval alone is not a migration. |
| A3/A4 | Remaining composite snapshot completeness and file/thumbnail consumer coverage | CODE REMAINING | Continue existing projections/replication; no unresolved policy choice. |
| A5 | Mixed and partially acknowledged chains, unsynced destinations, nested moves and legacy recovery | CODE REMAINING | Use existing grant/provenance/receipt foundations; preserve unsupported authored work. |
| B1 | Quantity custody ledger and optional serials | CODE REMAINING | Main business rules approved; no longer blocked on owner selection. |
| B2 | Quarantined salvage, inspection and reviewed recovery valuation | PARTIAL — batches and usable custody returns implemented; acceptance and repair boundaries remain | October29: native outbox/source pickers, generic receipts, atomic shared-source batches and canonical custody return reconciliation. PostgreSQL HTTP/races, SQLite and adapters PASS. Current build/deployment and GUI/reconnect acceptance tracked in primary evidence. Separate damaged-return repair handling and browser authoring/retry parity remain. |
| B3 | Connected requirements/BOM/tasks/experiments/canvas and remaining local mutations | CODE REMAINING | Canonical demand approved; integrate B1 quantities where stock effects apply. |
| B4 | Cancellation/closure propagation and settlement | PARTIAL — core awaiting deployment/verification | October 21: revision-fenced cancellation/completion/archive, unused reservation release and inventory settlement implemented. Coordinated migration/native build, in-flight pull/concurrency and end-to-end acceptance remain; broader review/recovery/history work remains separate. |
| B5/B6 | Remaining finance/import and inventory relationship/history/recovery paths | CODE REMAINING | Existing ordinary permission/version/outbox contract; custody-specific consumers depend on B1. |
| C1 | Validated, persisted editable assistant proposals | CODE REMAINING | No stock execution or automatic acceptance; use existing permissions/context boundaries. |
| C2 | Human acceptance of connected proposal graphs | DEPENDENCY | A1 enforcement plus B3/B4 graph/lifecycle contracts. |
| C3 | Device audio-focus coordinator | CODE REMAINING | No unresolved policy choice. |
| C4 | Consented provider transcription and microphone lifecycle | DEPENDENCY | Server-first boundary approved; C3 microphone focus plus provider/runtime implementation. |
| C5/C6 | Remaining durable automation intentions and authorized cached settings/users | CODE REMAINING | Administrative actions remain server-authoritative; no plaintext password outbox. |

Awaiting verification means code for the named subcheck exists, not that its
whole parent is ready. Keep full acceptance at phase end; use only quick builds
and focused critical invariant checks while finishing implementation.

## Phase-end acceptance register

Attach test cases and results to A1–C6. Retain existing historical passes as
evidence, but not as automatic passes on the final integrated build. For each
applicable gate record PASS, FAIL, BLOCKED (prerequisite) or NOT RUN; a nonapplicable
gate needs a reason. All gates start NOT RUN for this new integrated closure sweep.

1. Functional/safety: every closure behavior, permission denial and invariant;
   protocol/UUID normalization, atomic writes, no fallback after local failure.
2. Real offline desktop: stop only the actual LabOS API, retain DB/volumes, test
   navigation/refresh/files/writes/deletes, logout/login where relevant, cold
   restart and persistence. Pause/hung API additionally where timeout-sensitive.
3. Reconnect: existing actual PostgreSQL, push/pull, file integrity, lost ACK,
   retry/idempotency, delete propagation and pending-intent reconciliation.
4. Two clients/accounts: conflicts, concurrent stock/demand effects, visibility,
   expired/revoked access, stale replies and preserved rejected authored work.
5. Failure/recovery: crashes, interruption, malformed files/imports, disk-full,
   dependency failure and tested key/data recovery without replacing user data.
6. Full rerun/evidence: fix grouped root causes after independent tests finish;
   rerun earlier passes too, restore service state, record artifact/diff, exact
   fixtures and sanitized results. No unit/browser-only substitute for desktop.

## Status and next execution

October 17 primary review checkpoint: the A6/A4 downloaded-link pull omission has
a bounded source fix and 18 passing unit/contract checks; deployment and actual
PostgreSQL/Tauri outage/reconnect verification remain open. Both helper deliveries
have CHANGES REQUESTED in `docs/handoffs/phase2-parallel/PRIMARY_REVIEW_2026-10-17.md`.
Custody/salvage correctness, audio ownership and combined build failures prevent
promoting any B/C parent. The owner and primary now take over review/polish; a
helper report labelled complete is not accepted phase status. No closure count
is reduced by this checkpoint.

Baseline: 18 open closure items (12 PARTIAL, 6 PLANNED); none yet IMPLEMENTED in
full or CLOSED under this remaining-work checklist. Phase-wide sweep: NOT RUN.
These counts describe remaining obligations only, not all work already delivered.

October 13 implementation checkpoint — A5, with A1 permission boundaries retained:

- PDF/DOCX copies now record an explicit predecessor for an unsynced source
  creation, copy or content edit; server validation resolves its immutable receipt
  under the same author/device/source identity and rechecks current source access.
- Account-scoped conflict blocking/discard follows derived copies and later
  mutations; failed file transfers withhold dependent copies in the same pass.
  Retiring an intent does not delete any authored file or version record.
- Native edit access follows unconfirmed-copy ancestry with bounded cycle
  detection. An unconfirmed local creation is not treated as revoked merely
  because it is not in a server snapshot; confirmed-source denial still wins.
- This is source implementation, not a deployed build or acceptance pass. A5
  remains PARTIAL: metadata/attachment/folder chains, complete recovery workflows
  and integration/replay verification remain. A1 record-specific grants are not
  expanded by this change. Native rejection does not fall back to HTTP.

October 14 implementation checkpoint — A1 record edit authority foundation:

- Added bounded server edit-authority projections and native-only fetching from
  the compiled trusted origin. Cached decisions bind account, origin, resource,
  attachment/visibility, observed revision and the exact current login lease.
  No IPC-supplied positive grant or lease extension is accepted.
- Direct/shared/restricted resource editor checks for non-admins now consume that
  native cache rather than infer edit access from a renderer-fed project row.
  Note/folder inheritance stays blocked pending verified ancestor bindings;
  administrator behavior and other native writers still require the wider A1 audit.
- Owner delegated the content-only lease choice to the recommended approach.
  After safety review rejected a blanket revision relaxation, implementation kept
  exact-revision checks plus a narrow native-published content-chain proof for
  repeated saves. Scope changes, arbitrary versions, foreign accounts/devices,
  expired/replaced leases and retired unconfirmed versions cannot use that proof.
- New native revisions are recorded additively; old authored bytes/events are
  not deleted or rewritten. Legacy versions without proof remain fail-closed.
  Source implementation only: deployment and phase-end acceptance are still open.

October 14 follow-on checkpoint — A1 inherited source authority:

- Protocol 2 binds a complete leaf-to-root resource chain and attached-note
  visibility/project scope. Native code compares those bindings against the
  current account's SQLite records before allowing a non-admin source edit.
  Exact revisions/content-only proof and the existing login lease still apply.
- Server traversal detects cycles, missing notes/parents, non-folder ancestors
  and conflicting/multiple parents. Chains above 32 records fail closed rather
  than using a truncated authority context. This boundary needs real-data review
  during acceptance; no tree or authored work is deleted.
- Source grants do not authorize attachment destinations. Note/folder creation
  destinations and pending metadata/attachment chains remain open. Old caches
  need one verified refresh; deploy the compatible API before the new native
  binary. No restart or deployment occurred at this checkpoint.
- Critical pure checks passed (24 backend, seven native, six desktop adapters),
  with native test compilation and TypeScript checking. Actual PostgreSQL SQL,
  stopped-API desktop/restart and reconnect acceptance remain NOT RUN.

October 14 follow-on checkpoint — A1 destination grants and A5 edit-before-move:

- Project/note attachment destinations now have their own native-fetched,
  account/origin/scope/login-lease-bound decision cache. Non-admin project file
  writers no longer trust renderer-fed project edit flags; existing global
  project permission checks remain. Folder destinations check the folder's own
  verified resource grant, not the source file's grant. Administrator policy is
  not expanded. Verified project-note destinations can retain project visibility.
- Authority refresh now runs after resource/project/note pulls so a newly pulled
  note can receive a destination grant in the same pass. Denials replace cached
  positives; outages cannot extend leases. Deploy the API before the new binary.
- A direct attachment move can depend on its own pending native file creation,
  copy or content edit. Protocol 2 resolves the same author/device/resource
  receipt on the server and still checks current permissions and revisions.
  Conflicted/unsupported predecessors remain blocked; no authored bytes removed.
- Source implementation only, not deployed. Repeated attachment moves, generic
  metadata chains, new local-source grants for non-admins, new unsynced destination
  grants and folder/tree moves still remain. Full acceptance remains NOT RUN.

October 14 follow-on checkpoint — A1/A5 native-authored pending files:

- Fresh native file creations/copies now prove their own authorship using a ready
  upload record plus the same-account/device unsynced native outbox creation.
  No server grant is invented. Current resources view/edit/create permissions,
  login lease, verified destination scope and copy-source ancestry remain required.
- Further saves must retain scope/type/source identity and either the original
  native revision/size or a proven native content-edit chain. Conflicts, metadata
  changes, moved scope, retired creates and unsupported predecessors fail closed.
- This closes the blanket non-admin pre-first-sync editing restriction in source,
  not the whole new-record lifecycle. ACK-to-authority-refresh interruption,
  new unsynced destinations and repeated moves remain acceptance/implementation
  work. Source remains undeployed and all 18 closure units remain open.

October 14 follow-on checkpoint — A1/A5 verified confirmation handoff:

- File creation/copy/content confirmations now come directly from the trusted API
  into native code. Native selects up to 100 pending file events for the same
  resource/account/device, checks exact identity/operation/size and atomically
  stores verified receipts, authority decisions and acknowledgements. Changed
  pending work/session/lease causes a retry without rewriting the original events.
- Confirmation no longer requires current local edit permission: already-applied
  owned work can be acknowledged after access changes while the current authority
  remains denied. This fixes the source-level receipt guard that could stall an
  edit confirmation after a queued attachment move.
- Unchanged final local versions can adopt the matching verified server revision
  in that transaction. Newer local work is preserved; pending edits can trace
  through a native-confirmed creation receipt. Renderer-supplied file bindings and
  generic unverified file ACKs are blocked. Older binaries leave events pending
  with an upgrade message; deploy API then coordinated desktop build.
- Source implementation, not acceptance: real interruption/replay/database/UI
  cases remain NOT RUN. General metadata/repeated-move/folder chains and the
  post-move content-revision handoff still remain. All 18 closure units stay open.

October 14 follow-on checkpoint — A1/A5 native move and metadata chains:

- Direct repeated attachment moves and category/description/tag edits now share
  native-only before/after provenance and immutable predecessor IDs. Their local
  record, provenance and outbox event commit together. The source grant and every
  intervening move destination are rechecked; no old-scope grant is extended to
  content editing or copying. Metadata cannot alter visibility or attachments.
- New metadata writes use an explicit patch, preserve unspecified fields, capture
  account/native session, and reject old native binaries without an HTTP fallback.
  New `edit_metadata` intents are server revision-checked; protocol-3 moves can
  follow owned move/metadata receipts. Audit and metadata apply are transactional.
- Failed/discarded move and metadata intents propagate to dependent work. Saved
  provenance and file versions remain; conflicts do not auto-overwrite revisions.
- Scope remains PARTIAL: uninterrupted native move/metadata chains are covered;
  mixed content/create chains, partial-ACK continuation, legacy intents, unsynced
  destinations, folder/nested moves and content-after-move still need completion.
  Existing queued events are neither rewritten nor deleted. Not deployed.
- 24 backend pure/receipt-double, 28 native pure and 23 desktop adapter/dependency
  checks passed (75 total); TypeScript/native compilation passed. Actual database,
  stopped-API desktop and reconnect acceptance remain NOT RUN for this change.
  All 18 delivery items remain open; A1/A5 are not yet implementation-complete.

October 14 follow-on checkpoint — A6 independent download subchecks:

- Server diagnostics now use bounded parallel probes and a shared short-lived
  observation. The account-scoped native download snapshot retains a validated
  last-known check if an optional report is missing/invalid/older. Desktop tool
  reads use SQLite only; labels identify the observation time, not live worker
  health or file presence. First-check absence is unknown, not an empty success.
- Browser enqueue now persists an account/server/payload-bound request identity
  before HTTP and retains it on errors/reloads. The server serializes by receipt
  ID, checks current permission and exact receipt ownership, and commits the job,
  creation audit and receipt together. Existing active jobs are reused without
  another creation audit. Desktop enqueue remains native/outbox-only.
- Source implementation only. Both bounded subchecks are IMPLEMENTED — AWAITING
  VERIFICATION; A6 remains PARTIAL for worker/file reconciliation. Database and
  stopped-API desktop acceptance remain NOT RUN. No deployment/restart/reset.

October 15 follow-on checkpoint — A6 worker ownership and removal propagation:

- A dedicated PostgreSQL session lease now covers each complete download attempt.
  Recovery skips live leases, revokes the abandoned run ID before retry, and
  respects pending pause/cancel and retry ceilings. Claiming rechecks scheduler
  limits under a shared transaction lock. Progress/publication require the current
  attempt; previous callbacks cannot stop a newer attempt's process.
- Current requester active/role/permission/resource access is checked at claim,
  during execution and before publication. Changed source URL/type, missing
  resource or already-published media prevent stale publication. A real authority
  lookup failure stops monitored processes but is not fabricated as a revocation.
- Attempts use distinct filenames and no failure cleanup deletes previous bytes.
  Thumbnail preparation is optional, attempt-local and time-bounded; promotion
  does not overwrite an existing thumbnail. Captured process output and pending
  progress callbacks are bounded. Worker timestamps advance monotonically so a
  late progress snapshot cannot replace a newer terminal state at the same version.
- Download-history removal writes a scoped server tombstone transactionally.
  Existing committed removal receipts can backfill missing markers without hiding
  live jobs. Authorized snapshots supply markers; native merge retains them across
  later pulls and receipts. Reusing a retired job UUID is rejected. No resource,
  authored file, pending intent or previous attempt file is deleted by this work.
- Additive migration `20261014_download_worker_attempt.sql` is not applied yet.
  Stop all old-version API workers for coordinated deployment, apply migration,
  then start updated API and desktop builds; old workers do not honor new leases.
  Full database/outage/process acceptance remains NOT RUN. A6 remains PARTIAL.

October 15 follow-on checkpoint — A6 download PC-copy presentation:

- Queue/history thumbnails use native cached resource posters in desktop, never
  server or external thumbnail fallback. Missing/broken artwork has a placeholder.
- History reports current resource PC-copy availability separately from server job
  completion. Unknown local status does not erase the queue or claim absent bytes;
  local resource access is still required. Account/generation-bound reads reject
  switched sessions. Poster URLs are hidden immediately when their identity changes.
- Native copy observations distinguish stale revision/origin from the current copy;
  stale byte counts are not reported as progress on current content. Existing file
  presence/size and authorization checks remain required for ready presentation.
- 15 focused TypeScript adapter/presentation checks and two native pure checks
  passed; TypeScript and native compilation passed. No actual database, UI, outage,
  restart or deployment acceptance was run. A6 remains PARTIAL, not closed.

October 15 follow-on checkpoint — A1/A5 direct-mutation confirmation:

- Attach/metadata ACKs now require a native request to the trusted API, not a
  renderer-supplied success. Owned historical receipts carry bounded digests of
  the immutable intent and resulting scope/metadata. Current authority remains a
  separate verified snapshot; confirming historical work does not restore access.
- Native receipt, current authority and ACK commit atomically. Generic ACK cannot
  retire these mutations without native proof. Failed/old-binary confirmation
  preserves the intent and stable change ID for retry.
- A wholly native direct move/metadata chain can reconstruct an acknowledged
  prefix using origin/account/device/payload-bound receipts. Later work uses the
  latest confirmed result/revision for its authority check, validates the complete
  immutable chain and rechecks pending destinations. Missing proof, altered chains,
  current denials and mixed file-prefix chains remain blocked without data loss.
- This is source implementation, not deployed or phase sign-off. No database reset,
  migration, app restart or pending-work deletion. See the dated evidence for
  verification results and remaining integrated acceptance.
- Verification checkpoint: 45 focused pure/adapter checks passed, plus native
  test build/cargo check, TypeScript, backend syntax and diff checks. Actual
  PostgreSQL and stopped-API desktop acceptance remain NOT RUN.

Next: finish independent Batch A code, including remaining A6 consumer
and legacy/revocation reconciliation and A5 mixed/partial-ACK chains. A2 now has an approved recovery
policy; implementation must preserve all existing data. All five decision
blockers above are resolved; named code dependencies are not owner blockers.

October 16 checkpoint — A1/A5 file-confirmation prerequisite:

- New pending-file confirmations require negotiated protocol 2 and an exact
  committed-payload digest, not merely a matching resource/size. Native commit
  rechecks trusted origin as well as session/lease and unchanged saved work.
- 34 focused pure/adapter checks passed; native test compilation, backend syntax
  and scoped whitespace checks passed. Compatible API/native deployment and real
  PostgreSQL/outage acceptance remain pending. Legacy receipt provenance and mixed
  chains are still open; no parent item or phase is closed by this checkpoint.
- Phase 3 visual-agent spot review is recorded separately with CHANGES REQUESTED;
  its contributions and reported builds are not primary Phase 2 completion evidence.

Update format: `IDs changed | implementation-ready count / 18 | closed count / 18
| remaining IDs | exact blockers | next batch action`. Do not append unrelated
enhancements or treat a build/restart as an item closed.

## Source requirements and evidence

- [Three-phase scope](THREE_PHASE_REMAINING_WORK_PLAN.md)
- [Offline/security and real outage acceptance](PHASE2_OFFLINE_SECURITY_AND_ACCEPTANCE.md)
- [Salvage, project/custody, assistant and audio additions](PHASE2_3_SCOPE_ADDITIONS_2026-10-09.md)
- [Dated implementation and verification evidence](PHASE2_EVIDENCE.md)
- [Operation-level audit findings](OFFLINE_FIRST_WRITE_PATH_AUDIT.md)

This checklist governs remaining work/status and cadence. Source requirements
and audit details remain binding; dated later evidence supersedes earlier status
paragraphs. This documentation change does not itself implement or certify code.
